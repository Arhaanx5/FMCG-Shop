package com.shop.modules.billing;

import com.shop.modules.product.Product;
import com.shop.modules.product.UnitType;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "bill_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillItem {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "bill_id")
    private Bill bill;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    @Enumerated(EnumType.STRING)
    @Column(name = "unit_type")
    private UnitType unitType;

    private int quantity;

    @Column(name = "free_quantity")
    private int freeQuantity = 0;

    private BigDecimal rate;

    @Column(name = "gst_percent")
    private BigDecimal gstPercent = BigDecimal.ZERO;

    @Column(name = "gst_amount")
    private BigDecimal gstAmount = BigDecimal.ZERO;

    private BigDecimal total;
}