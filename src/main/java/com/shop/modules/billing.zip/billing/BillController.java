package com.shop.modules.billing;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/bills")
@RequiredArgsConstructor
public class BillController {

    private final BillService billService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Bill> getAll() {
        return billService.getAllBills();
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public Bill getById(@PathVariable UUID id) {
        return billService.getBillById(id);
    }

    @GetMapping("/pending")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Bill> getPending() {
        return billService.getPendingBills();
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public Bill createBill(
            @RequestBody BillService.CreateBillRequest req,
            Authentication auth) {
        return billService.createBill(req, auth.getName());
    }

    @GetMapping("/customer/{customerId}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Bill> getCustomerHistory(
            @PathVariable UUID customerId) {
        return billService.getCustomerHistory(customerId);
    }

    @PutMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<String> cancel(@PathVariable UUID id) {
        billService.cancelBill(id);
        return ResponseEntity.ok("Bill cancelled");
    }
}