package com.shop.modules.billing;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface BillRepository extends JpaRepository<Bill, UUID> {

    List<Bill> findByCustomerIdOrderByCreatedAtDesc(UUID customerId);

    @Query("SELECT b FROM Bill b WHERE " +
           "b.pendingAmount > 0 AND b.status = 'CONFIRMED'")
    List<Bill> findPendingBills();

    @Query("SELECT COALESCE(MAX(" +
           "CAST(SUBSTRING(b.billNumber, 6) AS int)" +
           "), 0) FROM Bill b WHERE b.billNumber LIKE 'BILL-%'")
    Integer findMaxBillSequence();

    @Query("SELECT b FROM Bill b WHERE " +
           "b.createdAt BETWEEN :start AND :end")
    List<Bill> findBillsBetween(
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end);

    List<Bill> findByCustomerId(UUID customerId);
}