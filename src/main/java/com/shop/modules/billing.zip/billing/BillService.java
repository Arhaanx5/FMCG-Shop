package com.shop.modules.billing;

import com.shop.modules.customer.Customer;
import com.shop.modules.customer.CustomerRepository;
import com.shop.modules.product.Product;
import com.shop.modules.product.ProductRepository;
import com.shop.modules.product.UnitType;
import com.shop.modules.stock.StockService;
import com.shop.modules.user.User;
import com.shop.modules.user.UserRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BillService {

    private final BillRepository billRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final StockService stockService;

    public List<Bill> getAllBills() {
        return billRepository.findAll();
    }

    public Bill getBillById(UUID id) {
        return billRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Bill not found: " + id));
    }

    public List<Bill> getPendingBills() {

        return billRepository.findPendingBills();
    }

    public List<Bill> getCustomerHistory(UUID customerId) {
        return billRepository
            .findByCustomerIdOrderByCreatedAtDesc(customerId);
    }

    @Transactional
    public Bill createBill(CreateBillRequest req,
                           String createdByPhone) {
        Customer customer = customerRepository
                .findById(req.getCustomerId())
                .orElseThrow(() ->
                    new RuntimeException("Customer not found"));

        User user = userRepository
                .findByPhone(createdByPhone)
                .orElseThrow(() ->
                    new RuntimeException("User not found"));

        String billNumber = generateBillNumber();

        Bill bill = Bill.builder()
                .billNumber(billNumber)
                .customer(customer)
                .paymentMode(req.getPaymentMode())
                .discount(req.getDiscount() != null
                    ? req.getDiscount() : BigDecimal.ZERO)
                .notes(req.getNotes())
                .createdBy(user)
                .status(BillStatus.CONFIRMED)
                .items(new ArrayList<>())
                .build();

        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal gstTotal = BigDecimal.ZERO;

        for (CreateBillRequest.BillItemRequest itemReq
                : req.getItems()) {

            Product product = productRepository
                    .findById(itemReq.getProductId())
                    .orElseThrow(() ->
                        new RuntimeException("Product not found"));

            BigDecimal rate = getRateForUnit(
                product, itemReq.getUnitType());

            BigDecimal itemSubtotal = rate.multiply(
                BigDecimal.valueOf(itemReq.getQuantity()));

            BigDecimal gstRate = product.getGstPercent()
                .divide(BigDecimal.valueOf(100));

            BigDecimal gstAmount = itemSubtotal
                .multiply(gstRate)
                .setScale(2, RoundingMode.HALF_UP);

            BigDecimal itemTotal = itemSubtotal.add(gstAmount);

            BillItem item = BillItem.builder()
                    .bill(bill)
                    .product(product)
                    .unitType(itemReq.getUnitType())
                    .quantity(itemReq.getQuantity())
                    .freeQuantity(itemReq.getFreeQuantity())
                    .rate(rate)
                    .gstPercent(product.getGstPercent())
                    .gstAmount(gstAmount)
                    .total(itemTotal)
                    .build();

            bill.getItems().add(item);
            subtotal = subtotal.add(itemSubtotal);
            gstTotal = gstTotal.add(gstAmount);

            // Deduct stock FIFO
            int ladiQty = 0;
            int bottleQty = 0;

            switch (itemReq.getUnitType()) {
                case LADI -> ladiQty = itemReq.getQuantity();
                case BOX  -> ladiQty = itemReq.getQuantity()
                                * product.getLadisPerBox();
                case CRATE -> bottleQty = itemReq.getQuantity() * 24;
                case BOTTLE -> bottleQty = itemReq.getQuantity();
                case PACK  -> ladiQty = itemReq.getQuantity();
            }

            stockService.deductStockFIFO(
                product.getId(), ladiQty, bottleQty);
        }

        BigDecimal grandTotal = subtotal
            .add(gstTotal)
            .subtract(bill.getDiscount());

        bill.setSubtotal(subtotal);
        bill.setGstTotal(gstTotal);
        bill.setGrandTotal(grandTotal);

        switch (req.getPaymentMode()) {
            case UDHAR -> {
                bill.setPaidAmount(BigDecimal.ZERO);
                bill.setPendingAmount(grandTotal);
            }
            case PARTIAL -> {
                BigDecimal paid = req.getPaidAmount() != null
                    ? req.getPaidAmount() : BigDecimal.ZERO;
                bill.setPaidAmount(paid);
                bill.setPendingAmount(grandTotal.subtract(paid));
            }
            default -> {
                bill.setPaidAmount(grandTotal);
                bill.setPendingAmount(BigDecimal.ZERO);
            }
        }

        // Update customer pending + last order
        customer.setTotalPending(
            customer.getTotalPending()
                .add(bill.getPendingAmount()));
        customer.setLastOrderAt(LocalDateTime.now());
        customerRepository.save(customer);

        return billRepository.save(bill);
    }

    private BigDecimal getRateForUnit(Product product,
                                       UnitType unitType) {
        return switch (unitType) {
            case BOX    -> product.getSellPriceBox();
            case LADI   -> product.getSellPriceLadi();
            case PACK   -> product.getSellPricePack();
            case BOTTLE -> product.getSellPriceBottle();
            case CRATE  -> product.getSellPriceBox();
        };
    }

    private String generateBillNumber() {
        Integer max = billRepository.findMaxBillSequence();
        int next = (max != null ? max : 0) + 1;
        return String.format("BILL-%05d", next);
    }

    public void cancelBill(UUID id) {
        Bill bill = getBillById(id);
        bill.setStatus(BillStatus.CANCELLED);
        billRepository.save(bill);
    }

    @Data
    public static class CreateBillRequest {
        private UUID customerId;
        private PaymentMode paymentMode;
        private BigDecimal discount;
        private BigDecimal paidAmount;
        private String notes;
        private List<BillItemRequest> items;

        @Data
        public static class BillItemRequest {
            private UUID productId;
            private UnitType unitType;
            private int quantity;
            private int freeQuantity;
        }
    }
}